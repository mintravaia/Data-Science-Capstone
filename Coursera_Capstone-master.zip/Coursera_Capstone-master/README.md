# Coursera Capstone
This repo will be mainly used for the capstone project for IBM Applied Data Science Capstone course on Coursera. 

_**Update:** This capstone project has been submitted in January 2019 as part of the requirements for completion of the IBM Data Science Professional Certificate on Coursera._

#### Full Report
File name: week5_final_report.pdf

#### Presentation Slides
File name: week5_presentation.pdf

#### Jupyter Notebook
File name: week5_final_report.ipynb

#### Tableau Visualization
https://public.tableau.com/profile/lim.chia.hooi#!/vizhome/Coursera_Capstone/KualaLumpur
